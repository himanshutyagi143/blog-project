<?php
require_once 'config/function.php';
require_once 'config/database.php';
security();
destroy();

#############################Query for fetching in all pages#########################
$admin_sid=$_SESSION['sid'];
$query = "SELECT * FROM `login` WHERE `aemail` = '$admin_sid'";
$data = mysqli_query($dbcon,$query);
$admin_res = mysqli_fetch_assoc($data);
#############################Query for fetching in all pages#########################



##############################Header Function##############################
head($admin_res['aname'],$admin_res['admin_theme'],$dbcon,$admin_sid);
##############################Header Function##############################

?>

<!--##############################mid Function#############################-->
<div class="mid">
<div class="mid-left fl">
<!--nav Section-->
<div class="nav">
<ul>

<?php
$query = "SELECT * FROM `nav_post`";
$nav_data = mysqli_query($dbcon,$query);

if (mysqli_num_rows($nav_data) > 0)
 {
  while($nav_res = mysqli_fetch_assoc($nav_data)) {
      ?>
      
      <li><a href="<?php echo $nav_res['url']; ?>"><img class="admin_icon" src="image/<?php echo $nav_res['icon'] ?>"><?php echo $nav_res['name']; ?></a></li>
    <?php
  }
}
?>
</ul>
</div>
<!--nav Section-->
</div>
<div class='mid-right fr'>
<?php
##############################mid Function##############################


##################Update button action#############
if(isset($_POST['update_sub']))
{
    extract($_POST);
    $post_id = $_GET['post_id'];
    $query = "UPDATE `post` SET `post_title`= '$upost_title', `post_msg` = '$upost_msg',`post_category` = '$upost_cata' WHERE `post_id` = '$post_id'";
    $data = mysqli_query($dbcon,$query);
    header('location: update-post.php?pid=update_post');
}
##################Update button action#############


##################edit button action###############
if(@$_GET['action'] == 'edit')
{
    $post_id = $_GET['post_id'];
    $query = "SELECT * FROM `post` WHERE `post_id` = '$post_id'";
    $data = mysqli_query($dbcon,$query);
    $res = mysqli_fetch_assoc($data);
    ?>


<!--------------------edit post ----------------------------->
<div class="post">
    <h2>Update Post</h2>
<form method="POST">
<p><input type="text" name="upost_title" value="<?php echo $res['post_title']; ?>" class="txt" required></p>
<p><textarea name="upost_msg" class="post_msg" required><?php echo $res['post_msg']; ?></textarea></p>
<p class="txt">Category
    <select name="upost_cata" required>
        <!-- <option value="">None</option> -->
        <option >UNCATEGORIZED</option>
        <option>HTML</option>
        <option>CSS</option>
        <option>JAVASCRIPT</option>
        <option>PHP</option>
    </select>
</p>
<p><input class="btn" type="submit" name="update_sub" value="Update Post"></p>
</form>
</div>
<br>

<!--------------------edit post ----------------------------->





    <?php
}
else
{
?>
<div class="post">
<h2>Update Post</h2>
</div>
<div class="post_table">
<?php
$query = "SELECT * FROM `post`";
$data = mysqli_query($dbcon,$query);
while($res = mysqli_fetch_assoc($data))
{
    ?>
   

    <h1><a href=""><?php echo $res['post_title'] ?></a></h1>
    <p><?php echo $res['post_msg'] ?></p>
    <br>
    <h4 style="border-bottom: 1px dashed"><?php echo $res['post_category'] ?>&nbsp;&nbsp;&nbsp;
    <a href="update-post.php?post_id=<?php echo $res['post_id']; ?>&action=edit">Edit Post</a>
    &nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;&nbsp;<a href="#"><?php echo $res['post_author'] ?></a>
    </h4>
    <br>
<?php
}
?>
</div>
<?php
}
#############################footer section######################
footer($dbcon);
#############################footer section######################
?>

