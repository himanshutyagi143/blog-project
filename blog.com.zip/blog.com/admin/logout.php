<?php
require_once 'config/function.php';
security();

?>