<?php
require_once 'database.php';
// Check the blank
function security()
{
    if($_SESSION['sid']=='')
        { 
            header('location:index.php');
         }
}

function security_a()
{
    if($_SESSION['sid']=='')
        { 
            header('location: ../index.php');
         }
}
security();
// Check the blank


// destroy the value of session 
function destroy()
{
    if(@$_GET['pid']=='logout')
{
    session_destroy();
    header('location:index.php');
}
}
// destroy the value of session 


// Header section

function head($admin_name,$css,$dbcon,$admin_sid)
{
 echo '  <!DOCTYPE html>';
 echo '<html lang="en">';
 echo '<head>';
 echo '<meta charset="UTF-8">';
 echo '<meta name="viewport" content="width=device-width, initial-scale=1.0">';
 echo "<title>{$admin_name} Panel</title>";
 echo "<link rel='stylesheet' href='css/{$css}'>";
 echo "<link rel='stylesheet' href='style.css'>";
 echo '<style>';
 echo "@import url('https://fonts.googleapis.com/css2?family=Fraunces:wght@300&display=swap')";
 echo '</style>';
 echo '</head>';
 echo "<body>";
//Header Section-->
echo " <div class='header'>";
echo " <div class='head'>";
echo " <div class='head-left fl'>";
$query="SELECT * FROM `login` WHERE `aemail` = '$admin_sid'";
$data = mysqli_query($dbcon,$query);
$res = mysqli_fetch_assoc($data);
echo " <img class='admin_ico1' src='image/";
echo $res['user_img'];
echo"' width='40px' height='40px'>"; 
echo " <a href='admin.php'>Howdy {$admin_name}</a>";
echo " </div>";
echo " <div class='head-right fr'>";
echo " <ul>";
echo " <li style='border-bottom: 1px dashed #fff;'><a href='../' target='_blank'>Go To Main Site</a></li>";
echo " <li><a href='?pid=logout'>Logout</a></li>";
echo "  </ul>";
echo " </div>";
echo " <div class='clr'></div>";
echo "</div>";
echo " </div>";
    //Header Section-->
}
//Header Section



function footer($dbcon)
{
$footer_query = "SELECT * FROM `footer`";
$footer_data = mysqli_query($dbcon,$footer_query);
$footer_res = mysqli_fetch_assoc($footer_data);
 echo'</div>';
 echo'<div class="clr"></div>';
 echo'</div>';
//mid Section-->
//footer Section-->
echo'<div class="footer">';
echo"<h4>Copyright &copy;";
echo $footer_res['value'];
 echo"</h4>";
echo'</div>';
//footer Section-->
echo'</body>';
echo'</html>';
}


?>