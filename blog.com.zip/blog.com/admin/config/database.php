<?php
session_start();
define("dbhost","localhost");
define("dbuser","root");
define("dbpass","");
define("dbname","blog");
$dbcon=mysqli_connect(dbhost,dbuser,dbpass,dbname);
?>