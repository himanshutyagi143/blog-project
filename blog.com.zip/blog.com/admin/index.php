<?php
require_once 'config/database.php';
if(isset($_POST['admin_login']))
{
    extract($_POST);
    $query = "SELECT * FROM `login`"; 
    $data = mysqli_query($dbcon,$query);
    $admin_res = mysqli_fetch_array($data);
    // validation on login form 
    if(empty($admin_email) && empty($admin_pass))
    {
        $msg = "Please Enter Email & Password";
    }
    else if(empty($admin_email))
    {
        $msg ="Please Enter Your Email";
    }
    else if(empty($admin_pass))
    {
        $msg ="Please Enter Your Password";
    }
    // checking id and password in database
    else
    {
        if($admin_email == $admin_res['aemail'] && $admin_pass == $admin_res['apass'])
        {
            // Define the session 
            $_SESSION['sid']=$admin_res['aemail'];
            header('location: admin.php');
        }
        else
        {
            $msg = "Id & Password do not match";
        }
    }
    
}
?>




<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login</title>
    <link rel="stylesheet" href="style.css">
    <style>
        /* body{ background-color:whitesmoke;} */
    </style>
</head>

<body>
    <div class="login">
    <h2>Admin Login</h2>
        <a href="./"><img src="image/logo.png" alt="image not found" width="30%"></a>
        <form method="post">
            <p><input type="email" name="admin_email" placeholder="Enter Admin Email" class="txt"></p>
            <p><input type="password" name="admin_pass" placeholder="Enter Admin Password" class="txt"></p>
            <p><input type="submit" name="admin_login" value="Admin Login" class="btn"></p>
            <br>
            <p class="msg"><?php echo @$msg; ?></p>
        </form>
        <br>
        <h4><a href="../">Back To Main Site</a></h4>
    </div>

</body>

</html>