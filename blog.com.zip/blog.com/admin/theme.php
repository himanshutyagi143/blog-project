<?php
require_once 'config/database.php';
require_once 'config/function.php';

// Check the blank
security();
// Check the blank


?>
<div class="post">
<h2>Themes</h2>
</div>
<div class="theme">
<ul>
    <li><a href="admin.php?theme=admin-theme.css&action=update_theme"><img src="theme/Theme1.png" width="25%"></a></li>
    <li><a href="admin.php?theme=admin-theme1.css&action=update_theme"><img src="theme/Theme2.png" width="25%"></a></li>
</ul>
</div>