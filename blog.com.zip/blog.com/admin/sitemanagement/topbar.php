<?php
##########################################################
$email_query = "SELECT * FROM `topbar_email`";
$email_data = mysqli_query($dbcon,$email_query);
$email_res = mysqli_fetch_array($email_data);
###########################################################

##########################################################
$phone_query = "SELECT * FROM `topbar_phone`";
$phone_data = mysqli_query($dbcon,$phone_query);
$phone_res = mysqli_fetch_array($phone_data);
###########################################################

##########################################################
$three_query = "SELECT * FROM `topbar_link3`";
$three_data = mysqli_query($dbcon,$three_query);
$three_res = mysqli_fetch_array($three_data);
###########################################################

##########################################################
$four_query = "SELECT * FROM `topbar_link4`";
$four_data = mysqli_query($dbcon,$four_query);
$four_res = mysqli_fetch_array($four_data);
###########################################################




######################################################
if(isset($_POST['update_email']))
{
    extract($_POST);
    $query = "UPDATE `topbar_email` SET `name`='$email_name',`value`='$email_value',`url`='$email_url' WHERE 1";
    $data = mysqli_query($dbcon,$query);
    header('location: site-mgmt.php?lid=topbar'); 
}
if(isset($_POST['update_phone']))
{
    extract($_POST);
    $query = "UPDATE `topbar_phone` SET `name`='$phone_name',`value`='$phone_value',`url`='$phone_url' WHERE 1";
    $data = mysqli_query($dbcon,$query);
    header('location: site-mgmt.php?lid=topbar'); 
}
if(isset($_POST['update_three']))
{
    extract($_POST);
    $query = "UPDATE `topbar_link3` SET `name`='$three_name',`value`='$three_value',`url`='$three_url' WHERE 1";
    $data = mysqli_query($dbcon,$query);
    header('location: site-mgmt.php?lid=topbar'); 
}
if(isset($_POST['update_four']))
{
    extract($_POST);
    $query = "UPDATE `topbar_link4` SET `name`='$four_name',`value`='$four_value',`url`='$four_url' WHERE 1";
    $data = mysqli_query($dbcon,$query);
    header('location: site-mgmt.php?lid=topbar'); 
}
#####################################################




?>
<!-------------------------------------------------------------------------------------------------->

<div style="text-align: center; width: 100%; background-color: #192929; color: #fff; padding-top: 1%; padding-bottom: 1%;">
    <h3>EMAIL ID</h3>
</div>
<br><br>
<form method="post">
      <div style="width: 49%; float: left; text-align: center;">
        <h4> NAME </h4>
        <input class="txt" name="email_name" type="text" value="<?php echo $email_res['name']; ?>">
      </div>
       
      <div style="text-align: center; width: 50%; float: right;">
      <h4> VALUE</h4>
      <input class="txt" type="text" name="email_value" value="<?php echo $email_res['value']; ?>"><br>
      </div>
      <div style="clear: both;"></div>
     
      <div style="text-align: center; width: 50%; margin: auto">
      <h4> URL</h4>
      <input class="txt" type="text" name="email_url" value="<?php echo $email_res['url']; ?>"><br>
      </div>

      <div style="text-align: center;">
         <input class="btn" name="update_email" type="submit" value="Update">
      </div>

</form>
<!-------------------------------------------------------------------------------------------------->
<br><br>


<!-------------------------------------------------------------------------------------------------->
<div style="text-align: center; width: 100%; background-color: #192929; color: #fff; padding-top: 1%; padding-bottom: 1%;">
    <h3>PHONE</h3>
</div>
<br><br>
<form method="post">
      <div style="width: 49%; float: left; text-align: center;">
        <h4> NAME</h4>
        <input class="txt" name="phone_name" type="text" value="<?php echo $phone_res['name']; ?>">
      </div>
       
      <div style="text-align: center; width: 50%; float: right;">
      <h4> VALUE</h4>
      <input class="txt" type="text" name="phone_value" value="<?php echo $phone_res['value']; ?>"><br>
      </div>
      <div style="clear: both;"></div>

      <div style="text-align: center; width: 50%; margin: auto">
      <h4> URL</h4>
      <input class="txt" type="text" name="phone_url" value="<?php echo $phone_res['url']; ?>"><br>
      </div>
     
      <div style="text-align: center;">
         <input class="btn" name="update_phone" type="submit" value="Update">
      </div>

</form>
<!-------------------------------------------------------------------------------------------------->


<br><br>



<!-------------------------------------------------------------------------------------------------->
<div style="text-align: center; width: 100%; background-color: #192929; color: #fff; padding-top: 1%; padding-bottom: 1%;">
    <h3>LINK 3</h3>
</div>
<br><br>
<form method="post">
      <div style="width: 49%; float: left; text-align: center;">
        <h4> NAME </h4>
        <input class="txt" name="three_name" type="text" value="<?php echo $three_res['name']; ?>">
      </div>
       
      <div style="text-align: center; width: 50%; float: right;">
      <h4> VALUE</h4>
      <input class="txt" type="text" name="three_value" value="<?php echo $three_res['value']; ?>"><br>
      </div>
      <div style="clear: both;"></div>

      <div style="text-align: center; width: 50%; margin: auto">
      <h4> URL</h4>
      <input class="txt" type="text" name="three_url" value="<?php echo $three_res['url']; ?>"><br>
      </div>
     
      <div style="text-align: center;">
         <input class="btn" name="update_three" type="submit" value="Update">
      </div>

</form>
<!-------------------------------------------------------------------------------------------------->


<br><br>



<!-------------------------------------------------------------------------------------------------->
<div style="text-align: center; width: 100%; background-color: #192929; color: #fff; padding-top: 1%; padding-bottom: 1%;">
    <h3>LINK 4</h3>
</div>
<br><br>
<form method="post">
      <div style="width: 49%; float: left; text-align: center;">
        <h4> NAME </h4>
        <input class="txt" name="four_name" type="text" value="<?php echo $four_res['name']; ?>">
      </div>
       
      <div style="text-align: center; width: 50%; float: right;">
      <h4> VALUE</h4>
      <input class="txt" type="text" name="four_value" value="<?php echo $four_res['value']; ?>"><br>
      </div>
      <div style="clear: both;"></div>

      <div style="text-align: center; width: 50%; margin: auto">
      <h4> URL</h4>
      <input class="txt" type="text" name="four_url" value="<?php echo $email_res['url']; ?>"><br>
      </div>
     
      <div style="text-align: center;">
         <input class="btn" name="update_four" type="submit" value="Update">
      </div>

</form>
<!-------------------------------------------------------------------------------------------------->
<br><br>