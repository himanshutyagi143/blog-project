<?php
##########################################################
$footer_query = "SELECT * FROM `footer`";
$footer_data = mysqli_query($dbcon,$footer_query);
$footer_res = mysqli_fetch_array($footer_data);
###########################################################


if(isset($_POST['update_footer']))
{
    extract($_POST);
    $query = "UPDATE `footer` SET `value`='$footer_value' WHERE 1";
    $data = mysqli_query($dbcon,$query);
    header('location: site-mgmt.php?lid=footer'); 
}


?>


<div style="text-align: center; margin-bottom: 5%; width: 100%; background-color: #192929; color: #fff; padding-top: 1%; padding-bottom: 1%;">
    <h3>FOOTER</h3>
</div>

<form method="post">
<div style="width: 90%; margin: auto;">
<div style="width: 20%; float: left;">
<h3>VALUE</h3>
</div>
<div style="width: 79%; float: right;">
<input class="txt" type="text" name="footer_value" value="<?php echo $footer_res['value']; ?>">
</div>
<div style="clear: both;"></div>
</div>
<div style="text-align: center;">
         <input name="update_footer" type="submit" value="Update" style="width: 80%; height: 40px; margin: auto;">
      </div>
</form>
