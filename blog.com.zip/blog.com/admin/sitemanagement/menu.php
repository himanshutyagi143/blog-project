<?php
// Check the blank
security_a();
// Check the blank


$query="SELECT * FROM `site_menu`";
$menu_data=mysqli_query($dbcon,$query);
?>

<div class="post">
    <h2>All Menus</h2>
</div>
<div class="menu_site_mgmt">
<ul>
<?php
while($menu_res=mysqli_fetch_array($menu_data))
{
    ?>
    <li><?php echo $menu_res['name']; ?></li>
    <?php
}
?>
</ul>
</div>

<!------------------------------------------------------------------------------------------->

<br><br>
<div class="menu_site_mgmt1">
<ul>
<a href=""><li>Add Menu</li></a>
<a href=""><li>Edit Menu</li></a>
<a href=""><li>Delete Menu</li></a>
</ul>
</div>