<?php
require_once 'config/database.php';
require_once 'config/function.php';
security();
destroy();

?>
<div class="site_mgmt_logo">
<img src="image/logo.png" width="30%">
</div>
<div style="margin-top: 5%; text-align: center;">
<form>
    <input type="file"><br><br>
    <input type="submit" value="Upload" style="width: 30%; padding: 1%;">
</form>
</div>