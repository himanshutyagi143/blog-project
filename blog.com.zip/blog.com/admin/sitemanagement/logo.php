<?php
require_once 'config/database.php';
require_once 'config/function.php';
security();
destroy();
 ##########################################
 $query="SELECT * FROM `image`";
 $data = mysqli_query($dbcon,$query);
 $res = mysqli_fetch_assoc($data);
 ##########################################
?>
<div class="site_mgmt_logo">
<img src="image/<?php echo $res['name']; ?>" width="<?php echo $res['width']; ?>">
</div>
<div style="margin-top: 5%; text-align: center;">
<form method="post" enctype="multipart/form-data">
    <input type="file" name="logo_img"><br><br>
    <input type="submit" name="upload_logo" value="Upload" style="width: 30%; padding: 1%;">
</form>
<br><br>
<p class="msg"><?php echo @$msg; ?></p>
</div>