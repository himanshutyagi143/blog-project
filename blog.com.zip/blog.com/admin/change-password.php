<?php
require_once 'config/function.php';
security();
$query = "SELECT * FROM `login` WHERE `aemail` = '{$_SESSION['sid']}'";
$admin_data = mysqli_query($dbcon,$query);
$admin_res = mysqli_fetch_assoc($admin_data);



?>

<div class="post">
<h2>Profile </h2>

<form method="POST" enctype="multipart/form-data">
<p><img src="image/admin.png" width="20%"></p>
<p><input type="file" name="admin"></p>
<br>
<p><input type="text" name="uname" value="<?php echo $admin_res['aname']; ?>" class="txt" required></p>
<p><input name="uemail" value="<?php echo $admin_res['aemail']; ?>" class="txt" required></textarea></p>
<p><input type="password" name="upass" value="<?php echo $admin_res['apass']; ?>"class="txt" required></p>
<p><input class="btn" type="submit" name="update_log" value="Update"></p>
</form>
</div>