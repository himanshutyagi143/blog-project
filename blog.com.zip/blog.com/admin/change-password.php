<?php
require_once 'config/function.php';
security();
$query = "SELECT * FROM `login` WHERE `aemail` = '{$_SESSION['sid']}'";
$admin_data = mysqli_query($dbcon,$query);
$admin_res = mysqli_fetch_assoc($admin_data);


##########################################
$query="SELECT * FROM `login` WHERE `aemail` = '$admin_sid'";
$data = mysqli_query($dbcon,$query);
##########################################

 

?>

<div class="post">
<h2>Profile </h2>

<form method="POST" enctype="multipart/form-data">
<?php
    while($res = mysqli_fetch_assoc($data))
    { 
        ?>
<p><img src="image/<?php echo $res['user_img']; ?>" width="80px" height="80px"></p>
<?php
    }
    ?>
<p><input type="file" name="admin_img"></p>
<br>
<p><input type="text" name="uname" value="<?php echo $admin_res['aname']; ?>" class="txt" required></p>
<p><input name="uemail" value="<?php echo $admin_res['aemail']; ?>" class="txt" required></textarea></p>
<p><input type="password" name="upass" value="<?php echo $admin_res['apass']; ?>"class="txt" required></p>
<p><input class="btn" type="submit" name="update_log" value="Update"></p>
</form>
</div>