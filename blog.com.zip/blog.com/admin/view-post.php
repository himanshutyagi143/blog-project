<?php
require_once 'config/function.php';
security();
?>
<div class="post">
<h2>View Post</h2>
</div>

<div class="post_table">
<?php
#############################post active or deactive show code ########################
$query = "SELECT * FROM `post` WHERE `post_status` = 1";
$data = mysqli_query($dbcon,$query);
#############################post active or deactive show code ########################
while($res = mysqli_fetch_assoc($data))
{
    ?>
   
    <h1><a href=""><?php echo $res['post_title'] ?></a></h1>
    <p><?php echo $res['post_msg'] ?></p>
    <br>
    <h4 style="border-bottom: 1px dashed"><?php echo $res['post_category'] ?>
    &nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;&nbsp;<a href="#"><?php echo $res['post_author'] ?></a>
    </h4>
    <br>

<?php
}
?>
</div>