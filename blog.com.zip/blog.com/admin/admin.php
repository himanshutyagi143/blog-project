<?php
require_once 'config/database.php';
require_once 'config/function.php';

// Check the blank
security();
// Check the blank

// destroy the value of session 
destroy();
// destroy the value of session 


// Hold the value of session 
$admin_sid=$_SESSION['sid'];
$query="SELECT * FROM `login` WHERE `aemail` = '$admin_sid'";
$admin_data=mysqli_query($dbcon,$query);
$admin_res=mysqli_fetch_array($admin_data);



#############################Add Post & duplicate title Code###########################################
if(isset($_POST['post_sub']))
{
    extract($_POST);
    $query = "SELECT * FROM `post` WHERE `post_title` = '$upost_title'";
    $data = mysqli_query($dbcon,$query);
    $res = mysqli_fetch_assoc($data);
    if($res['post_title'] == $upost_title)
    {
       $msg = "Please Choose Unique Title";
    }

    else
    {
    extract($_POST);
    $query = "INSERT INTO `post` (`post_id`, `post_title`, `post_msg`, `post_category`, `post_author`) VALUES (NULL, '$upost_title', '$upost_msg', '$upost_cata', '{$_SESSION['sid']}')";
    $data = mysqli_query($dbcon,$query);
    $msg = "Post Created Sucessfully";
}
}
#############################Add Post & duplicate title Code###########################################



#############################Query for fetching in all pages#########################
$query = "SELECT * FROM `post`";
$data = mysqli_query($dbcon,$query);
#############################Query for fetching in all pages#########################


############################Activate / Deactivate post code########################
if(@$_GET['pstatus'] == 'active')
{
    $post_id = $_GET['postid'];
    $query = "UPDATE `post` SET `post_status` = 1 WHERE `post_id` = '$post_id'";
    $data = mysqli_query($dbcon,$query);
    header('location: admin.php?pid=active_post');
}
elseif(@$_GET['pstatus'] == 'deactive')
{
    $post_id = $_GET['postid'];
    $query = "UPDATE `post` SET `post_status` = 0 WHERE `post_id` = '$post_id'";
    $data = mysqli_query($dbcon,$query);
    header('location: admin.php?pid=active_post');
}
############################Activate / Deactivate post code########################



############################Delete post code########################
if(@$_GET['action'] == 'delete')
{
    $post_id = $_GET['postid'];
    $query = "DELETE FROM `post` WHERE `post_id` = '$post_id'";
    $data = mysqli_query($dbcon,$query);
    header('location: admin.php?pid=delete_post');
}

############################Delete post code########################


############################Update user setting########################
if(isset($_POST['update_log']))
{
    // image upload code
$size = $_FILES['admin']['size']/1048576;
if($size <= 2)
{
move_uploaded_file($_FILES['admin']['tmp_name'],$_FILES['admin']['name']);
}
else
{
    echo "File size too big";
}

    extract($_POST);
    $user_id = $_GET['user_id'];
    $query = "UPDATE `login` SET `aname`= '$uname', `aemail` = '$uemail',`apass` = '$upass' WHERE `aemail` = '{$_SESSION['sid']}'";
    $data = mysqli_query($dbcon,$query);
    session_destroy();
    header('location: index.php');
}

######################################Header Function#############################################
head($admin_res['aname'],$admin_res['admin_theme']);
######################################Header Function#############################################





####################################Update Theme################################################
if(@$_GET['action'] == 'update_theme')
{
    $theme = $_GET['theme'];
    $query="UPDATE `login` SET `admin_theme`='$theme' WHERE `aemail`='$admin_sid'";
    $data = mysqli_query($dbcon,$query);
    header('location: admin.php?pid=theme');
}

####################################Update Theme################################################



############################## mid Section##############################
?>
<div class="mid">
<div class="mid-left fl">
<!--nav Section-->
<div class="nav">
<ul>

<?php
$query = "SELECT * FROM `nav_post`";
$nav_data = mysqli_query($dbcon,$query);

if (mysqli_num_rows($nav_data) > 0)
 {
  while($nav_res = mysqli_fetch_assoc($nav_data)) {
      ?>
      
    <li><a href="<?php echo $nav_res['url']; ?>"><img class="admin_icon" src="image/<?php echo $nav_res['icon'] ?>"><?php echo $nav_res['name']; ?></a></li>
    <?php
  }
}
?>
</ul>
</div>
<!--nav Section-->
</div>
<div class='mid-right fr'>
<!--############################## mid Section##############################-->





      
        <?php
            @$pageid = $_GET['pid'];
            // print_r($pageid); Used only for testing
            switch($pageid)
            {
                case "dashboard":
                require_once 'dashboard.php';
                break;
                case "add_post":
                    require_once 'add-post.php';
                    break;
                    case "active_post":
                        require_once 'post-varifi.php';
                        break;
                        case "view_post":
                            require_once 'view-post.php';
                            break;
                            case "update_post":
                                require_once 'update-post.php';
                                break;
                                case "delete_post":
                                    require_once 'delete-post.php';
                                    break;
                                    case "user_setting":
                                        require_once 'change-password.php';
                                        break;
                                        case "theme":
                                            require_once 'theme.php';
                                            break;
                default: require_once 'dashboard.php';
            }
#############################footer section######################
            footer("2020-2021");
#############################footer section######################
        ?>
       
