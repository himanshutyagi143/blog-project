<?php
require_once 'config/function.php';
security();

?>
<div class="post">
<h2>Delete Post </h2>
</div>
<div class="post_table">
<?php
while($res = mysqli_fetch_assoc($data))
{
    ?>
   

    <h1><a href=""><?php echo $res['post_title'] ?></a></h1>
    <p><?php echo $res['post_msg'] ?></p>
    <br>
    <h4 style="border-bottom: 1px dashed"><?php echo $res['post_category'] ?>
   &nbsp;&nbsp;&nbsp;&nbsp; | &nbsp;&nbsp;&nbsp;&nbsp;<a href="#"><?php echo $res['post_author'] ?></a> &nbsp;&nbsp;&nbsp;&nbsp;| &nbsp;&nbsp;&nbsp;&nbsp;
    <a href="?action=delete&postid=<?php echo $res['post_id']; ?>">Delete Post</a>
    </h4>
    <br>

<?php
}
?>
</div>