<?php
require_once 'config/database.php';
require_once 'config/function.php';
security();
destroy();
// Hold the value of session 
$admin_sid=$_SESSION['sid'];
$query="SELECT * FROM `login` WHERE `aemail` = '$admin_sid'";
$admin_data=mysqli_query($dbcon,$query);
$admin_res=mysqli_fetch_array($admin_data);

######################################Header Function#############################################
head($admin_res['aname'],$admin_res['admin_theme']);
######################################Header Function#############################################


########################################Add advertise button###################################################
if(isset($_POST['create_sub']))
{
    extract($_POST);
    $query = "INSERT INTO `advertise` (`id`, `ads`) VALUES (NULL, '$ad_title')";
    $data = mysqli_query($dbcon,$query);
    $msg = "Advertise Created Sucessfully";
}
########################################Add advertise button###################################################

?>
<div class="mid">
<div class="mid-left fl">
<!--nav Section-->
<div class="nav">
<ul>

<?php
$query = "SELECT * FROM `nav_post`";
$nav_data = mysqli_query($dbcon,$query);

if (mysqli_num_rows($nav_data) > 0)
 {
  while($nav_res = mysqli_fetch_assoc($nav_data)) {
      ?>
      
    <li><a href="<?php echo $nav_res['url']; ?>"><img class="admin_icon" src="image/home.png"><?php echo $nav_res['name']; ?></a></li>
    <?php
  }
}
?>
</ul>
</div>
<!--nav Section-->
</div>
<div class='mid-right fr'>

<div class="post">
    <h2>Add Advertise</h2>
<form method="POST">
<p><input type="text" name="ad_title" class="txt" required></p>
<p><input class="btn" type="submit" name="create_sub" value="Create Advertise"></p>
</form>
<br>
<h4 style="text-align: center; color: red;"><?php echo @$msg; ?></h4>
</div>

<?php
#############################footer section######################
footer("2020-2021");
#############################footer section######################
?>