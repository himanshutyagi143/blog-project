<?php
require_once 'config/function.php';
security();
?>
<div class="post">
<h2>Dashboard</h2>
</div>
