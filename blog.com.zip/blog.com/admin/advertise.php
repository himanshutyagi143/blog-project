<?php
require_once 'config/database.php';
require_once 'config/function.php';
security();
destroy();

// Hold the value of session 
$admin_sid=$_SESSION['sid'];
$query="SELECT * FROM `login` WHERE `aemail` = '$admin_sid'";
$admin_data=mysqli_query($dbcon,$query);
$admin_res=mysqli_fetch_array($admin_data);

######################################Header Function#############################################
head($admin_res['aname'],$admin_res['admin_theme'],$dbcon,$admin_sid);
######################################Header Function#############################################


###########################################update button action########################################################
if(isset($_POST['update_sub']))
{
    extract($_POST);
    $aid = $_GET['aid'];
    $query = "UPDATE `advertise` SET `ads`= '$ad_title' WHERE `id` = '$aid'";
    $ad_data = mysqli_query($dbcon,$query);
    header('location: advertise.php');
}
############################################update button action####################################################



############################################Delete button action####################################################
if(@$_GET['action'] == 'delete')
{
    $aid = $_GET['aid'];
    $query = "DELETE FROM `advertise` WHERE `id`='$aid'";
    $ad_data = mysqli_query($dbcon,$query);
    header('location: advertise.php');
}
############################################Delete button action####################################################
?>




    <div class="mid">
<div class="mid-left fl">
<!--nav Section-->
<div class="nav">
<ul>

<?php
$query = "SELECT * FROM `nav_post`";
$nav_data = mysqli_query($dbcon,$query);

if (mysqli_num_rows($nav_data) > 0)
 {
  while($nav_res = mysqli_fetch_assoc($nav_data)) {
      ?>
      
      <li><a href="<?php echo $nav_res['url']; ?>"><img class="admin_icon" src="image/<?php echo $nav_res['icon'] ?>"><?php echo $nav_res['name']; ?></a></li>
    <?php
  }
}
?>
</ul>
</div>
<!--nav Section-->
</div>
<div class='mid-right fr'>
  <?php      
##################################Edit button action################################################################
if(@$_GET['action'] == 'edit')
{
    $aid = $_GET['aid'];
    $query = "SELECT * FROM `advertise` WHERE `id` = '$aid'";
    $ad_data = mysqli_query($dbcon,$query);
    $ad_res = mysqli_fetch_assoc($ad_data);

    ?>
<div class="post">
    <h2>Update Advertise</h2>
<form method="POST">
<p><input type="text" name="ad_title" value="<?php echo $ad_res['ads']; ?>" class="txt" required></p>
<p><input class="btn" type="submit" name="update_sub" value="Update Advertise"></p>
</form>
</div>
<br>

<?php
}
else
{
    
?>


<div class="advertise">
    <h2>Advertisement</h2>
       <a style="text-align: right;" href="add-advertise.php">Add New</a>
</div>
<?php
$query="SELECT * FROM `advertise`";
$ad_data = mysqli_query($dbcon,$query);
while($ad_res = mysqli_fetch_assoc($ad_data))
{
?>

<table border="1" style="text-align: center;">
<tr>
<td width="5%"><img style="width: 100%;" src="image/icon.gif"></td>
<td width="70%"><a href="#"><?php echo $ad_res['ads']; ?></a></td>
<td><a href="?aid=<?php echo $ad_res['id']; ?>&action=edit">Edit</a></td>
<td><a href="?aid=<?php echo $ad_res['id']; ?>&action=delete">Delete</a></td>

</tr>
</table>
<?php
}}

############################## edit button action##############################




#############################footer section######################
footer($dbcon);
#############################footer section######################
 

?>