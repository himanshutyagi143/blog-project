<?php
require_once 'config/function.php';
security();
?>
<div class="post">
    <h2>Add New Post</h2>
<form method="POST">
<p><input type="text" name="upost_title" placeholder="Enter Post Name" class="txt" required></p>
<p><textarea name="upost_msg" class="post_msg" required></textarea></p>
<p class="txt">Category
    <select name="upost_cata" required>
        <option>UNCATEGORIZED</option>
        <option>HTML</option>
        <option>CSS</option>
        <option>JAVASCRIPT</option>
        <option>PHP</option>
    </select>
</p>
<p><input class="btn" type="submit" name="post_sub" value="Create Post"></p>
</form>
</div>
<br>
<div>
<h4 class="post_msg"><?php echo @$msg; ?></h4>
</div>