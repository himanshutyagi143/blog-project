<?php
require_once 'config/database.php';
require_once 'config/function.php';
security();
destroy();

// Hold the value of session 
$admin_sid=$_SESSION['sid'];
$query="SELECT * FROM `login` WHERE `aemail` = '$admin_sid'";
$admin_data=mysqli_query($dbcon,$query);
$admin_res=mysqli_fetch_array($admin_data);

######################################Header Function#############################################
head($admin_res['aname'],$admin_res['admin_theme'],$dbcon,$admin_sid);
######################################Header Function#############################################



######################## logo upload code#######################################################
if(isset($_POST['upload_logo']))
{
// image upload code
$size = $_FILES['logo_img']['size']/1048576;
$type = $_FILES['logo_img']['type'];
$arr = array("image/png","image/jpeg");
if($type == "image/png" OR $type == "image/jpeg")
{
    if($size <= 2 )
    {
        $temp = $_FILES['logo_img']['tmp_name'];
        $name = $_FILES['logo_img']['name'];
        $query = "UPDATE `image` SET `name`='$name',`width`='25%'";
        $data = mysqli_query($dbcon,$query);
    move_uploaded_file($temp,"image/$name");
    $msg = "Logo Uploaded Sucessfully";
    }
    else
    {
        $msg = "Image Size must be less than 2 mb";
    }
}
elseif($type != "image/jpeg")
{
    $msg = "Image should be in jpg or png";
}
elseif($type != "image/png")
{
    $msg = "Image should be in jpg or png";
}
else
{
    $msg = "Image should be in jpg or png";
    $msg = "Image Size must be less than 2 mb";
}
}

#####################################################################################################


?>
<div class="mid">
<div class="mid-left fl">
<!--nav Section-->
<div class="nav">
<ul>

<?php
$query = "SELECT * FROM `nav_post`";
$nav_data = mysqli_query($dbcon,$query);

if (mysqli_num_rows($nav_data) > 0)
 {
  while($nav_res = mysqli_fetch_assoc($nav_data)) {
      ?>
      
    <li><a href="<?php echo $nav_res['url']; ?>"><img class="admin_icon" src="image/<?php echo $nav_res['icon'] ?>"><?php echo $nav_res['name']; ?></a></li>
    <?php
  }
}
?>
</ul>
</div>
<!--nav Section-->
</div>
<div class='mid-right fr'>

  <!------------------------------------------------------------------->
<div class="post">
    <h2>Site Management</h2>
</div>

  <div class="site_mgmt">
    <div class="left_site_mgmt fl">
        <ul>
          <a href="?lid=logo"><li>LOGO</li></a>
          <a href="?lid=menu"><li>MENUS</li></a>
          <a href="?lid=topbar"><li>TOP BAR</li></a>
          <a href="?lid=footer"><li>FOOTER</li></a>
          </ul>
    </div>
    <div class="right_site_mgmt fr">

    <?php
      @$lid=$_GET['lid'];
      switch($lid)
      {
          case "logo":
          require_once 'sitemanagement/logo.php';
          break;
          case "menu":
              require_once 'sitemanagement/menu.php';
              break;
              case "topbar":
                  require_once 'sitemanagement/topbar.php';
                  break;
                  case "footer":
                      require_once 'sitemanagement/footer.php';
                      break;
                      default: require_once 'sitemanagement/logo.php';
                  }

    ?>

      </div>
      <div class="clr"></div>
  </div>
  <!------------------------------------------------------------------->

<?php
#############################footer section######################
footer($dbcon);
#############################footer section######################
 
?>