<?php
$query = "SELECT * FROM `post` WHERE `post_category` = 'JAVASCRIPT'";
$data = mysqli_query($dbcon,$query);
?>

<div class="post_table">
            <?php
                while($res = mysqli_fetch_assoc($data))
                    {
             ?>
   
    <h1><a href=""><?php echo $res['post_title'] ?></a></h1>
    <p><?php echo $res['post_msg'] ?></p>
    <br>
    <h4 style="border-bottom: 1px dashed"><?php echo $res['post_category'] ?>
    &nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;&nbsp;<a href="mailto:<?php echo $res['post_author'] ?>"><?php echo $res['post_author'] ?></a>
    </h4>
<br>
<?php
}
?>
</div>