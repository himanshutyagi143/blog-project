<?php
require_once 'config/database.php';
require_once 'config/function.php';
#############################post active or deactive show code ########################
$query = "SELECT * FROM `post` WHERE `post_status` = 1";
$data = mysqli_query($dbcon,$query);
#############################post active or deactive show code ########################

head($dbcon);
?>

<!--nav Section-->
    <div class="nav bg3">
    <ul>
    <?php
    $query = "SELECT * FROM `site_menu`";
    $site_data = mysqli_query($dbcon,$query);
    while($site_res = mysqli_fetch_assoc($site_data))
    {
    ?>
    <a href="<?php echo $site_res['url']; ?>"><li><?php echo $site_res['name']; ?></li></a>
    <?php
    }
    ?>
    </ul>
    </div>
<!--nav Section-->

    <!--mid Section-->
    <div class="mid">
        <div class="mid-left fl">

        <?php
############################Menu selection code##################################################
@$page_id = $_GET['pid'];
switch($page_id)
{
    case "html":
        require_once 'html.php';
        break;
        case "css":
            require_once 'css.php';
            break;
            case "home":
                require_once 'home.php';
                break;
                case "javascript":
                    require_once 'javascript.php';
                    break;
                    case "php":
                        require_once 'php.php';
                        break;
            default: require_once 'home.php';

}
##################################Menu selection code#############################################
?>


        </div>
        <div class="mid-right fr">

    <h2 style="text-align: center; background-color: #e0d7d7; text-align: center; padding: 2%; margin-bottom: 3%;">Advertisement</h2>

<?php
$query="SELECT * FROM `advertise`";
$ad_data = mysqli_query($dbcon,$query);
while($ad_res = mysqli_fetch_assoc($ad_data))
{
?>

<table style=" border-bottom: 1px dashed; width: 93%; margin: auto; margin-bottom: 2%; ">
<tr>

<td width="10%"><img style="width: 100%;" src="image/icon.gif"></td>
<td><a href="https://www.sarkarijobs.com" target="_blank"><?php echo $ad_res['ads']; ?></a></td>
</tr>
</table>
<?php
}
footer($dbcon);
?>