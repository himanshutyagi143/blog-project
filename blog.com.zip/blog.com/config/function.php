<?php

function head($dbcon)
{

    echo' <!DOCTYPE html>';
    echo'<html lang="en">';
    echo'<head>';
    echo'<meta charset="UTF-8">';
    echo'<meta name="viewport" content="width=device-width, initial-scale=1.0">';
    echo'<title>SoftYouth Software Solutions</title>';
    echo'<link rel="stylesheet" href="style.css">';
    echo'</head>';
    echo'<body>';
     //<!-- Topbar section -->
  
     echo'<div class="topbar">';
     echo'<ul><marquee onMouseOver="this.stop()" onMouseOut="this.start()">';
     $topquery = "SELECT * FROM `topbar_email`";
     $topdata = mysqli_query($dbcon,$topquery);
     $topres = mysqli_fetch_array($topdata);
     echo'<li>';
     echo $topres['name'];
     echo ': <a href="';
     echo $topres['url'];
     echo '">';
     echo $topres['value'];  
     echo'</a></li>';
     echo'<li>|</li>';
     $topquery = "SELECT * FROM `topbar_phone`";
    $topdata = mysqli_query($dbcon,$topquery);
    $topres = mysqli_fetch_array($topdata);
    echo'<li>';
    echo $topres['name'];
    echo ': <a href="';
     echo $topres['url'];
     echo '">';
     echo $topres['value'];
     echo '</a></li>';
     echo'<li>|</li>';
     $topquery = "SELECT * FROM `topbar_link3`";
    $topdata = mysqli_query($dbcon,$topquery);
    $topres = mysqli_fetch_array($topdata);
    echo'<li>';
    echo $topres['name'];
    echo ': <a href="';
     echo $topres['url'];
     echo '" target="_blank">';
     echo $topres['value'];
     echo '</a></li>';
     echo'<li>|</li>';
     $topquery = "SELECT * FROM `topbar_link4`";
    $topdata = mysqli_query($dbcon,$topquery);
    $topres = mysqli_fetch_array($topdata);
    echo'<li>';
    echo $topres['name'];
    echo ': <a href="';
     echo $topres['url'];
     echo '" target="_blank">';
     echo $topres['value'];
     echo '</a></li>';
     echo'</marquee></ul>';
     echo'</div>';
     //<!-- Topbar section -->
    //<!--Header Section-->
    echo '<div class="header bg2">';
    echo '<div class="head">';
    echo '<div class="head-left fl">';
    ##########################################
    $query="SELECT * FROM `image`";
    $data = mysqli_query($dbcon,$query);
    ##########################################
    $res = mysqli_fetch_assoc($data);
    echo "<a href='./'><img src='admin/image/";
    echo $res['name'];
    echo"' width='";
    echo $res['width'];
    echo"' style='position: relative; top: 24px'></a>";
    echo '</div>';
    echo "<div class='head-right fr'>";
    echo "<a href='/ducat/php/blog.com/admin'><h4>Admin Login</h4></a>";
    echo '</div>';
    echo '<div class="clr"></div>';
    echo '</div>';
    echo '</div>';
    //<!--Header Section-->
}

function footer($dbcon)
{
    $footer_query = "SELECT * FROM `footer`";
$footer_data = mysqli_query($dbcon,$footer_query);
$footer_res = mysqli_fetch_array($footer_data);
    echo '</div>';
    echo '<div class="clr"></div>';
    echo '</div>';
    //<!--mid Section-->
    //<!--footer Section-->
    echo '<div class="footer bg2">';
    echo '<h4>Copyright &copy;';
    echo $footer_res['value'];
    echo'</h4>';
    echo '</div>';
    //<!--footer Section-->
    echo '</body>';
    echo '</html>';
}

?>