<?php
$key = 1;
?>