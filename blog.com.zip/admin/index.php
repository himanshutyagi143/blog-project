<?php
require_once 'config/database.php';
require_once 'validation.php';
if(isset($_POST['admin_login']))
{
    extract($_POST);
    $query = "SELECT * FROM `login` WHERE `aemail`='$admin_email' and `apass`='$admin_pass'"; 
    $data = mysqli_query($dbcon,$query);
    $res = mysqli_fetch_array($data);
    // validation on login form 
    if(empty($admin_email) && empty($admin_pass))
    {
        $msg = "Please Enter Email & Password";
    }
    else if(empty($admin_email))
    {
        $msg ="Please Enter Your Email";
    }
    else if(empty($admin_pass))
    {
        $msg ="Please Enter Your Password";
    }
    // checking id and password in database
    else
    {
        if($res['aemail'] == $admin_email and $res['apass'] == $admin_pass)
        {
            header("location: admin.php");
        }
        else
        {
            $msg = "Id & Password do not match";
        }
    }
    
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style.css">
</head>

<body class="admin_body_login">
    <div class="login">
        <a href="./"><img src="image/logo.png" alt="image not found" class="admin_logo"></a>
        <form method="post">
            <p><input type="email" name="admin_email" placeholder="Enter Admin Email" class="txt"></p>
            <p><input type="password" name="admin_pass" placeholder="Enter Admin Password" class="txt"></p>
            <p><input type="submit" name="admin_login" value="Admin Login" class="btn"></p>
            <p class="msg"><?php echo @$msg; ?></p>
        </form>
        <h4><a href="../">Back To Main Site</a></h4>
    </div>

</body>

</html>